# AI Performance Guardrails 🛡️

**Stop your AI from pushing bloated, 10-second-load-time garbage to production.**

This repository is a strict verification loop that forces AI coding assistants (like Claude Code, Cursor, GitHub Copilot) to run Lighthouse performance checks *before* finalizing code chunks. If the score drops below 100%, the AI is instructed to refine its own code until it passes.

## Why use this?
- **Frictionless Adoption:** Drop these files into your project and your AI agent instantly becomes performance-aware.
- **Self-Healing Code:** The AI reads the Lighthouse failure logs, identifies the bottleneck, and rewrites the code to fix it.
- **Zero Bloat:** Keep your Next.js, React, or Vue apps blazing fast without manually auditing every AI-generated component.

## ⚡ The "Voila" Installation

For **Claude Code**, it is completely automatic. Claude natively looks for a `CLAUDE.md` file in your project root and absorbs its instructions immediately. There is no plugin to install or settings menu to configure.

Just run these commands in your terminal to pull the guardrails into your project:

```bash
# 1. Grab the AI instructions and Lighthouse config
curl -O https://raw.githubusercontent.com/YOUR_GITHUB_NAME/ai-performance-guardrails/main/CLAUDE.md
curl -O https://raw.githubusercontent.com/YOUR_GITHUB_NAME/ai-performance-guardrails/main/lighthouserc.js

# 2. Grab the enforcer script
mkdir -p scripts && curl -o scripts/check-speed.js https://raw.githubusercontent.com/YOUR_GITHUB_NAME/ai-performance-guardrails/main/scripts/check-speed.js

# 3. Install the Lighthouse CI dependency
npm install -D @lhci/cli
```

Finally, add the script to your `package.json`:
```json
"scripts": {
  "check-speed": "node scripts/check-speed.js"
}
```

**Done.** The next time you type `claude` in your terminal, the AI will strictly enforce 100% Lighthouse scores on its own code.

## How it Works

1. The AI writes or updates a chunk of code.
2. The `CLAUDE.md` prompt forces the AI to run `npm run check-speed`.
3. The script builds your project and runs Lighthouse.
4. If the score is < 100, the script fails. The AI reads the error output, refines the code, and tries again.

## Contributing
Feel free to submit Pull Requests to add support for Playwright, Cypress, or tweak the GitHub Actions!

---
*Built to keep the web fast.*
